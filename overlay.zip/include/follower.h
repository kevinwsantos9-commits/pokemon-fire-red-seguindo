#ifndef GUARD_FOLLOWER_H
#define GUARD_FOLLOWER_H

#include "global.h"
#include "sprite.h"

#define LOCALID_FOLLOWER   253
#define FOLLOWER_PAL_TAG   0x1121

extern u16 gFollowerPalette[16];
extern struct SpriteFrameImage gFollowerPicTable[2];

void Follower_Update(void);

#endif // GUARD_FOLLOWER_H
